package config

const (
	Mysqldb = "root:123456@tcp(127.0.0.1:3306)/ranking?charset=utf8"
)