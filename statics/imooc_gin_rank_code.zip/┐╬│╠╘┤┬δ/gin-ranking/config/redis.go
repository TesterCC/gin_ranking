package config

const (
	RedisAddress = "localhost:6379"
)
